* [Notes](#notes)

To see the class plan, go to [Class 1 Plan](../jc_001-new.html)

### Notes

This class went very well. The kids were active and eager to participate. Don't forget to provide a snack for your child!!
